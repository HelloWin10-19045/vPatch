Add-Type -AssemblyName System.Windows.Forms
$ni = New-Object System.Windows.Forms.NotifyIcon
$ni.Icon = [System.Drawing.SystemIcons]::Information
$ni.BalloonTipTitle  = "vPatch"
$ni.BalloonTipText   = "vPatch������ ������"
$ni.Visible = $true
$ni.ShowBalloonTip(3000)
$ni.Dispose()