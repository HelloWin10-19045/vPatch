Add-Type -AssemblyName System.Windows.Forms
$ni = New-Object System.Windows.Forms.NotifyIcon
$ni.Icon = [System.Drawing.SystemIcons]::Information
$ni.BalloonTipTitle  = "vPatch Uninstaller"
$ni.BalloonTipText   = "vPatchӦ�ó��� ��ж��"
$ni.Visible = $true
$ni.ShowBalloonTip(3000)
$ni.Dispose()