Add-Type -AssemblyName System.Windows.Forms
$ni = New-Object System.Windows.Forms.NotifyIcon
$ni.Icon = [System.Drawing.SystemIcons]::Information
$ni.BalloonTipTitle  = "vPatch Updater"
$ni.BalloonTipText   = "�°汾�� vPatch 19.0 �Ѿ���"
$ni.Visible = $true
$ni.ShowBalloonTip(3000)
$ni.Dispose()