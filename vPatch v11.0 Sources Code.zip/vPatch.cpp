#include <windows.h>
using namespace std;
int main()
{
	system ("title vPatch");
	system ("powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\\Windows\\vPatch\\vPatch.ps1");
	while (true){
	HWND hWnd = FindWindowA(NULL, "���Ͽ��Ҳɼ���");
    PostMessage (hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);
    PostMessage (FindWindowA(NULL,"��������"), WM_CLOSE, 0, 0);
    Sleep (100);
}
	return 0;
}
