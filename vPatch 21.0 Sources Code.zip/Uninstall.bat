@echo off
title vPatch Uninstaller
:home
cls
set a=%random%
set b=%random%
set c=%random%
set d=%random%
set /a i=%a%*%b%+%c%-%d%
set /p password=������ vPatch ��ж������ (vpatchuninstallpassword%a%ntcrt%b%jdkipd%c%n9kdf%d%wdfue): 
if "%password%"=="%i%" goto uninstall
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Windows\vPatch\UIShow\Uninstaller0.ps1
goto home
:uninstall
cls
echo �������ж�� vPatch Ӧ�ó���...
pause >nul
cls
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\vPatch.exe" /F >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SilentProcessExit\vPatch.exe" /F >nul
@taskkill /f /im NSudo.exe >nul 2>&1
@taskkill /f /im vPatch.exe >nul 2>&1
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 1 /F >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" /v "vPatch" /F >nul
reg delete HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run /v vPatch /F >nul
reg delete HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\vPatch /F >nul
del /f /q "%UserProFile%\Desktop\vPatch.lnk" >nul
del /f /q "%UserProFile%\Desktop\vPatch Unlocker.lnk" >nul
rd /s /q "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\vPatch Software"
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Windows\vPatch\UIShow\Uninstaller1.ps1
rd /s /q C:\Windows\vPatch
exit