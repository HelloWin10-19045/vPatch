@echo off
title vPatch �Զ�����
rd /s /q C:\Windows\vPatch\UpdateDownload
mkdir C:\Windows\vPatch\UpdateDownload
bitsadmin /transfer vPatch_Update /priority normal https://gitee.com/Hello-Win10/vPatch-Update/raw/master/vPatch_22.0_Setup.exe "C:\Windows\vPatch\UpdateDownload\vPatch_Update.exe" || exit
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Windows\vPatch\UIShow\Updater.ps1
@taskkill /f /im wlrmdr.exe >nul 2>&1
timeout /t 10 /nobreak >nul
start "" C:\Windows\vPatch\UpdateDownload\vPatch_Update.exe -el4328 -s2 "-dC:\Windows\vPatch" "-sp"
exit