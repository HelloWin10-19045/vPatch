@echo off
title vPatch �����ʼ��
@taskkill /f /im NSudo.exe >nul 2>&1
@taskkill /f /im vPatch.exe >nul 2>&1
regedit /s C:\Windows\vPatch\vPatch_Program.reg
regedit /s C:\Windows\vPatch\vPatch_Protect.reg
attrib +s +h +r C:\Windows\vPatch\*
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /F >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" /v "vPatch" /F >nul
reg add HKLM\Software\Microsoft\Windows\CurrentVersion\Run /v vPatch /t REG_SZ /d "C:\Windows\vPatch\NSudo.exe -U:P -P:E -ShowWindowMode:Hide C:\Windows\vPatch\vPatch.exe" /F >nul
start "" C:\Windows\vPatch\NSudo.exe -U:P -P:E -ShowWindowMode:Hide C:\Windows\vPatch\vPatch.exe
mkdir "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\vPatch Software"
copy /y "C:\Windows\vPatch\UIShow\vPatch.lnk" "%UserProFile%\Desktop" >nul
copy /y "C:\Windows\vPatch\UIShow\vPatch Unlocker.lnk" "%UserProFile%\Desktop" >nul
copy /y "C:\Windows\vPatch\UIShow\vPatch.lnk" "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\vPatch Software" >nul
copy /y "C:\Windows\vPatch\UIShow\vPatch Unlocker.lnk" "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\vPatch Software" >nul
copy /y "C:\Windows\vPatch\UIShow\vPatch Uninstaller.lnk" "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\vPatch Software" >nul
exit