@echo off
title vPatch Unlocker
:home
cls
set a=%random%
set b=%random%
set c=%random%
set /a i=%a%+%b%+%c%-100
set /p password=������ vPatch �Ľ������� (vpatchunlockpassword%a%jdk%b%rtcds%time%upd%c%): 
if "%password%"=="%i%" goto unlock
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Windows\vPatch\UIShow\Unlocker0.ps1
goto home
:unlock
cls
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\vPatch.exe" /F >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SilentProcessExit\vPatch.exe" /F >nul
@taskkill /f /im NSudo.exe >nul 2>&1
@taskkill /f /im vPatch.exe >nul 2>&1
regedit /s C:\Windows\vPatch\vPatch_Protect.reg
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Windows\vPatch\UIShow\Unlocker1.ps1
exit